from flask import Flask,render_template,redirect
app=Flask(__name__)

@app.route("/")
def index():
    return render_template("patiodejuegos.html")
@app.route("/play/<int:y>")
def cantDiv(y):
    return render_template("patiodejuegos.html",y=y)
@app.route('/play/<int:y>/<string:color>')
def xAnyColorDiv(y,color):
    return  render_template("patiodejuegos.html",y=y,color=color);





if __name__=="__main__":
    app.run(debug=True)